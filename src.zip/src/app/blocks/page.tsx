// src/app/blocks/page.tsx
"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { useBlocks } from "@/hooks/useBlocks";
import type { Block, Entry } from "@/data/blocks";
import { summarizeBlockLLM } from "@/lib/summarize";

/** Petit gestionnaire d'historique local (undo/redo + coalescing) */
function useUndoManager(initial = "", coalesceMs = 400) {
  const [value, setValue] = useState(initial);
  const undoStack = useRef<string[]>([]);
  const redoStack = useRef<string[]>([]);
  const lastPushTs = useRef<number>(0);

  // snapshot courant “version enregistrée” (externe)
  const savedSnapshotRef = useRef<string>(initial);

  // reset complet (ex: changement de bloc)
  const reset = (next: string) => {
    undoStack.current = [];
    redoStack.current = [];
    lastPushTs.current = 0;
    savedSnapshotRef.current = next;
    setValue(next);
  };

  // quand l’extérieur enregistre réellement (persistance OK)
  const markSaved = (currentPersisted: string) => {
    savedSnapshotRef.current = currentPersisted;
  };

  const canUndo = () => undoStack.current.length > 0;
  const canRedo = () => redoStack.current.length > 0;

  const push = (next: string) => {
    const now = Date.now();
    const since = now - lastPushTs.current;
    // coalesce: si modifs très rapprochées, on écrase le sommet
    if (since > coalesceMs || undoStack.current.length === 0) {
      undoStack.current.push(value);
    } else {
      undoStack.current[undoStack.current.length - 1] = value;
    }
    lastPushTs.current = now;
    // tape une nouvelle valeur → vide redo
    redoStack.current = [];
    setValue(next);
  };

  const onChange = (next: string) => {
    push(next);
  };

  const undo = () => {
    if (!canUndo()) return;
    const prev = undoStack.current.pop()!;
    redoStack.current.push(value);
    setValue(prev);
  };

  const redo = () => {
    if (!canRedo()) return;
    const next = redoStack.current.pop()!;
    undoStack.current.push(value);
    setValue(next);
  };

  const revertToSaved = () => {
    const saved = savedSnapshotRef.current ?? "";
    if (saved === value) return;
    // on empile la valeur actuelle dans undo, comme une “étape”
    undoStack.current.push(value);
    redoStack.current = [];
    setValue(saved);
  };

  return {
    value, setValue, onChange,
    reset, markSaved,
    undo, redo, revertToSaved,
    canUndo, canRedo,
    getSaved: () => savedSnapshotRef.current,
  };
}

export default function BlocksPage() {
  const { loading, blocks, setSummary, setContent, renameBlock } = useBlocks();
  const list = useMemo(() => (blocks ? Object.values(blocks) : []), [blocks]);

  const [activeId, setActiveId] = useState<string>("");
  const active = useMemo<Block | null>(
    () => (activeId && blocks ? blocks[activeId] ?? null : list[0] ?? null),
    [activeId, blocks, list]
  );

  // sélection par défaut
  useEffect(() => {
    if (!loading && list.length && !activeId) setActiveId(list[0].id);
  }, [loading, list, activeId]);

  const [error, setError] = useState<string | null>(null);
  const [summarizing, setSummarizing] = useState<string | null>(null);

  // ----- Titre éditable -----
  const [titleDraft, setTitleDraft] = useState<string>("");
  useEffect(() => {
    setTitleDraft(active?.title || "");
  }, [active?.id]);

  // ----- Mémoire (contenu) — avec historique -----
  const contentMgr = useUndoManager("", 400);
  const [contentSaveState, setContentSaveState] = useState<"idle" | "saving" | "saved">("idle");
  const contentTimerRef = useRef<number | null>(null);

  // hydrate mémoire quand on change de bloc
  useEffect(() => {
    const initial = active?.content ?? "";
    contentMgr.reset(initial);
    setContentSaveState("idle");
    if (contentTimerRef.current) {
      window.clearTimeout(contentTimerRef.current);
      contentTimerRef.current = null;
    }
  }, [active?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  // autosave mémoire (debounce 600ms)
  useEffect(() => {
    if (!active?.id) return;
    const current = contentMgr.value;
    if (current === (active.content ?? "")) return;
    setContentSaveState("saving");
    if (contentTimerRef.current) window.clearTimeout(contentTimerRef.current);
    contentTimerRef.current = window.setTimeout(async () => {
      try {
        await setContent(active.id, current);
        setContentSaveState("saved");
        contentMgr.markSaved(current); // aligne le snapshot “enregistré”
        window.setTimeout(() => setContentSaveState("idle"), 800);
      } catch {
        setContentSaveState("idle");
      }
    }, 600) as unknown as number;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [contentMgr.value, active?.id]);

  // ----- Résumé IA — avec historique -----
  const summaryMgr = useUndoManager("", 400);
  const [summarySaveState, setSummarySaveState] = useState<"idle" | "saving" | "saved">("idle");
  const summaryTimerRef = useRef<number | null>(null);

  // hydrate résumé quand on change de bloc
  useEffect(() => {
    const initial = active?.summary ?? "";
    summaryMgr.reset(initial);
    setSummarySaveState("idle");
    if (summaryTimerRef.current) {
      window.clearTimeout(summaryTimerRef.current);
      summaryTimerRef.current = null;
    }
  }, [active?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  // autosave résumé (debounce 600ms)
  useEffect(() => {
    if (!active?.id) return;
    const current = summaryMgr.value ?? "";
    if (current === (active.summary ?? "")) return;
    setSummarySaveState("saving");
    if (summaryTimerRef.current) window.clearTimeout(summaryTimerRef.current);
    summaryTimerRef.current = window.setTimeout(async () => {
      try {
        await setSummary(active.id, current);
        setSummarySaveState("saved");
        summaryMgr.markSaved(current); // sync snapshot
        window.setTimeout(() => setSummarySaveState("idle"), 800);
      } catch {
        setSummarySaveState("idle");
      }
    }, 600) as unknown as number;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [summaryMgr.value, active?.id]);

  if (loading || !blocks) return <div className="p-6">Chargement…</div>;
  if (!list.length) return <div className="p-6">Aucun bloc.</div>;

  return (
    <main className="max-w-5xl mx-auto p-6 space-y-6">
      <header className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Blocs</h1>
      </header>

      {/* Sélecteur de bloc */}
      <section className="space-y-2 border rounded-xl p-4 bg-white">
        <label className="text-sm font-medium">Bloc</label>
        <select
          className="w-full border rounded p-2 text-sm"
          value={active?.id || ""}
          onChange={(e) => setActiveId(e.target.value)}
        >
          {list.map((b) => (
            <option key={b.id} value={b.id}>
              {b.title} — {b.entries.length} entrées ({b.progress}%)
            </option>
          ))}
        </select>
      </section>

      {active && (
        <>
          {/* En-tête : titre éditable */}
          <section className="space-y-2 border rounded-xl p-4 bg-white">
            <div className="text-xs uppercase tracking-wide text-gray-500">
              Titre du bloc
            </div>
            <div className="flex gap-2">
              <input
                className="flex-1 border rounded p-2 text-sm"
                value={titleDraft}
                onChange={(e) => setTitleDraft(e.target.value)}
              />
              <button
                className="px-3 py-2 border rounded text-sm hover:bg-gray-50"
                onClick={async () => {
                  const t = (titleDraft || "").trim();
                  if (!t || t === active.title) return;
                  await renameBlock(active.id, t);
                }}
              >
                Renommer
              </button>
            </div>
          </section>

          {/* Résumé IA — ÉDITABLE + Undo/Redo + Revenir à la version enregistrée */}
          <section className="space-y-2 border rounded-xl p-4 bg-white">
            <div className="flex items-center justify-between">
              <div className="text-xs uppercase tracking-wide text-gray-500">
                Résumé (IA) — {active.title}
              </div>
              <div className="flex items-center gap-2">
                {error && <span className="text-xs text-red-600">{error}</span>}
                {/* Régénérer (réécrit dans le textarea → autosave) */}
                <button
                  className="px-3 py-2 border rounded text-sm hover:bg-gray-50 disabled:opacity-50"
                  disabled={!!summarizing}
                  onClick={async () => {
                    try {
                      setError(null);
                      setSummarizing(active.id);
                      const summary = await summarizeBlockLLM(active);
                      summaryMgr.onChange(summary); // passe par l'historique
                    } catch (e: any) {
                      console.error("Résumé échoué:", e);
                      setError("Résumé impossible pour le moment.");
                    } finally {
                      setSummarizing(null);
                    }
                  }}
                  title="Générer ou régénérer le résumé"
                >
                  {summarizing === active.id ? "⏳ Résumage…" : "↻ Régénérer"}
                </button>

                {/* Annuler / Rétablir / Revenir à la version enregistrée */}
                <button
                  className="px-2 py-2 border rounded text-sm hover:bg-gray-50 disabled:opacity-50"
                  onClick={summaryMgr.undo}
                  disabled={!summaryMgr.canUndo()}
                  title="Annuler la dernière modification"
                >
                  ⟲ Annuler
                </button>
                <button
                  className="px-2 py-2 border rounded text-sm hover:bg-gray-50 disabled:opacity-50"
                  onClick={summaryMgr.redo}
                  disabled={!summaryMgr.canRedo()}
                  title="Rétablir"
                >
                  ⟳ Rétablir
                </button>
                <button
                  className="px-2 py-2 border rounded text-sm hover:bg-gray-50"
                  onClick={summaryMgr.revertToSaved}
                  title="Revenir à la dernière version enregistrée"
                >
                  ⏮ Revenir à la version enregistrée
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <p className="text-xs text-gray-500">
                Éditable librement. Autosave ~600 ms après la dernière frappe.
              </p>
              <div className="text-xs">
                {summarySaveState === "saving" && <span className="text-gray-500">Enregistrement…</span>}
                {summarySaveState === "saved" && <span className="text-green-600">Enregistré ✓</span>}
                {summarySaveState === "idle" && <span className="text-gray-400">—</span>}
              </div>
            </div>

            <textarea
              className="w-full border rounded p-3 text-sm bg-indigo-50/40"
              rows={10}
              placeholder="Le résumé (IA) s’écrit ici… Tu peux le modifier directement."
              value={summaryMgr.value}
              onChange={(e) => summaryMgr.onChange(e.target.value)}
            />
          </section>

          {/* Mémoire (brut) — ÉDITABLE + Undo/Redo + Revenir à la version enregistrée */}
          <section className="space-y-2 border rounded-xl p-4 bg-white">
            <div className="flex items-center justify-between">
              <div className="text-xs uppercase tracking-wide text-gray-500">
                Mémoire (brut) — {active.title}
              </div>
              <div className="flex items-center gap-2">
                <button
                  className="px-2 py-1 border rounded text-xs hover:bg-gray-50 disabled:opacity-50"
                  onClick={contentMgr.undo}
                  disabled={!contentMgr.canUndo()}
                  title="Annuler la dernière modification"
                >
                  ⟲ Annuler
                </button>
                <button
                  className="px-2 py-1 border rounded text-xs hover:bg-gray-50 disabled:opacity-50"
                  onClick={contentMgr.redo}
                  disabled={!contentMgr.canRedo()}
                  title="Rétablir"
                >
                  ⟳ Rétablir
                </button>
                <button
                  className="px-2 py-1 border rounded text-xs hover:bg-gray-50"
                  onClick={contentMgr.revertToSaved}
                  title="Revenir à la dernière version enregistrée"
                >
                  ⏮ Version enregistrée
                </button>
                <div className="text-xs ml-2">
                  {contentSaveState === "saving" && <span className="text-gray-500">Enregistrement…</span>}
                  {contentSaveState === "saved" && <span className="text-green-600">Enregistré ✓</span>}
                  {contentSaveState === "idle" && <span className="text-gray-400">—</span>}
                </div>
              </div>
            </div>

            <textarea
              className="w-full border rounded p-3 text-sm bg-gray-50"
              rows={12}
              placeholder="Édite librement le récit du bloc…"
              value={contentMgr.value}
              onChange={(e) => contentMgr.onChange(e.target.value)}
            />
          </section>

          {/* Historique Q/R */}
          <section className="space-y-2 border rounded-xl p-4 bg-white">
            <div className="text-xs uppercase tracking-wide text-gray-500">
              Historique Q/R — {active.title}
            </div>
            {active.entries.length === 0 ? (
              <div className="text-sm text-gray-500 italic">— vide —</div>
            ) : (
              <ul className="space-y-2">
                {active.entries.slice().reverse().map((e: Entry, i: number) => (
                  <li key={i} className="border rounded p-3 bg-white">
                    {"q" in e && (
                      <div className="text-sm">
                        <span className="font-medium">Q:&nbsp;</span>
                        {(e as any).q}
                      </div>
                    )}
                    {"a" in e && (
                      <div className="text-sm">
                        <span className="font-medium">A:&nbsp;</span>
                        {(e as any).a}
                      </div>
                    )}
                  </li>
                ))}
              </ul>
            )}
          </section>
        </>
      )}
    </main>
  );
}
