"use client";

import React, { useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { PageNavButtons } from "@/components/ui/PageNavButtons";
import { useBlocks } from "@/hooks/useBlocks";

type Block = { id: string; title?: string; summary?: string };
type Chapter = { id: string; title: string; text: string; images?: (string | { page: number; src: string })[] };

const LS_KEY_BUILDER = "draft:builder:v1";
const LS_KEY_FINAL = "draft:final:v1";
const LS_KEY_HISTORY = "draft:final:history";
const CHARS_PER_PAGE = 1600;

function splitIntoPages(text: string, charsPerPage = CHARS_PER_PAGE): string[] {
  const t = text.trim();
  if (!t) return [""];
  const pages: string[] = [];
  let i = 0;
  while (i < t.length) {
    const slice = t.slice(i, i + charsPerPage);
    const lastPara = slice.lastIndexOf("\n\n");
    const cut = lastPara > 400 ? lastPara + 2 : slice.length;
    pages.push(t.slice(i, i + cut).trim());
    i += cut;
  }
  return pages.length ? pages : [t];
}

function todayISO() {
  return new Date().toLocaleDateString(undefined, {
    year: "numeric",
    month: "long",
    day: "numeric",
  });
}

function debounce<T extends (...args: any[]) => void>(fn: T, delay = 600) {
  let t: any;
  return (...args: Parameters<T>) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...args), delay);
  };
}

// Pagination par hauteur réelle pour du texte brut (paragraphes séparés par deux sauts de ligne)
function paginateTextByHeight(input: string): string[] {
  if (typeof window === "undefined") return [input || ""];
  const PAGE_HEIGHT = 1020;
  const PAD_TOP = 56; // p-14
  const PAD_BOTTOM = 96; // pb-24
  const INNER_HEIGHT = PAGE_HEIGHT - PAD_TOP - PAD_BOTTOM; // ~868px
  const PAGE_WIDTH = 720;
  const PAD_X = 56; // p-14
  const INNER_WIDTH = PAGE_WIDTH - PAD_X * 2; // ~608px

  const text = String(input || "").replace(/<[^>]+>/g, "");
  const paragraphs = text.split(/\n\n+/);
  if (!paragraphs.length) return [""];

  const meas = document.createElement("div");
  meas.style.position = "fixed";
  meas.style.left = "-99999px";
  meas.style.top = "-99999px";
  meas.style.width = `${INNER_WIDTH}px`;
  meas.style.fontFamily = "ui-serif, Georgia, Cambria, \"Times New Roman\", Times, serif";
  meas.style.fontSize = "15px";
  meas.style.lineHeight = "1.9";
  meas.style.visibility = "hidden";
  document.body.appendChild(meas);

  let pages: string[][] = [[]];
  let currentHeight = 0;

  const paraEls: HTMLParagraphElement[] = [];
  try {
    for (const para of paragraphs) {
      const p = document.createElement("p");
      p.style.margin = "0 0 16px 0";
      p.textContent = para;
      meas.appendChild(p);
      const h = p.offsetHeight;
      paraEls.push(p);
      if (h > INNER_HEIGHT && pages[pages.length - 1].length === 0) {
        // Paragraphe plus haut qu'une page: on le force seul sur une page
        pages[pages.length - 1].push(para);
        pages.push([]);
        meas.innerHTML = "";
        currentHeight = 0;
        continue;
      }
      if (currentHeight + h > INNER_HEIGHT && pages[pages.length - 1].length > 0) {
        pages.push([]);
        meas.innerHTML = "";
        currentHeight = 0;
        // Remesure dans nouvelle page
        const p2 = document.createElement("p");
        p2.style.margin = "0 0 16px 0";
        p2.textContent = para;
        meas.appendChild(p2);
        const h2 = p2.offsetHeight;
        currentHeight += h2;
        pages[pages.length - 1].push(para);
        continue;
      }
      currentHeight += h;
      pages[pages.length - 1].push(para);
    }
  } finally {
    document.body.removeChild(meas);
  }

  // Convertit pages de tableaux -> string par page
  return pages
    .map((paras) => paras.join("\n\n").trim())
    .filter((s, i, arr) => i === 0 || s.length > 0 || i < arr.length - 1 || arr.length === 1);
}

async function compressImage(file: File, maxDim = 1280, quality = 0.85): Promise<string> {
  const img = document.createElement("img");
  const url = URL.createObjectURL(file);
  try {
    await new Promise((resolve, reject) => {
      img.onload = () => resolve(null);
      img.onerror = reject;
      img.src = url;
    });
    const { width, height } = img as HTMLImageElement;
    let targetW = width;
    let targetH = height;
    if (width > height && width > maxDim) {
      targetW = maxDim;
      targetH = Math.round((height / width) * maxDim);
    } else if (height >= width && height > maxDim) {
      targetH = maxDim;
      targetW = Math.round((width / height) * maxDim);
    }
    const canvas = document.createElement("canvas");
    canvas.width = targetW;
    canvas.height = targetH;
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("canvas");
    ctx.drawImage(img, 0, 0, targetW, targetH);
    return canvas.toDataURL("image/jpeg", quality);
  } finally {
    URL.revokeObjectURL(url);
  }
}

function stripImageTags(html: string | undefined | null): string {
  if (!html) return "";
  try {
    // Supprime les balises <img ...> (souvent data: base64) pour l'historique
    return String(html).replace(/<img[^>]*>/gi, "");
  } catch {
    return String(html || "");
  }
}

function toHistorySnapshot(state: { prefaceHtml?: string; conclusionHtml?: string; chapters?: any[] }) {
  const prefaceHtml = stripImageTags(state.prefaceHtml);
  const conclusionHtml = stripImageTags(state.conclusionHtml);
  const chapters = (state.chapters || []).map((ch) => ({
    id: ch?.id ?? "",
    title: ch?.title ?? "",
    text: ch?.text ?? "",
    // On ne stocke pas les images en historique pour éviter le dépassement de quota
    images: [],
  }));
  return { prefaceHtml, conclusionHtml, chapters };
}

function BookPage({
  children,
  showFooter,
  pageNumber,
  bookTitle,
  onAddImage,
  noShadow,
}: {
  children: React.ReactNode;
  showFooter?: boolean;
  pageNumber?: number;
  bookTitle?: string;
  onAddImage?: () => void;
  noShadow?: boolean;
}) {
  return (
    <div
      className={`relative w-[720px] h-[1020px] mx-auto bg-[#fdfaf6] rounded-[18px] ${
        noShadow ? "" : "shadow-[0_25px_60px_rgba(0,0,0,0.12)]"
      } border border-gray-200 overflow-hidden mb-8`}
      style={{ contain: "strict" }}
    >
      <div className="absolute inset-0 overflow-hidden p-14 pb-24 font-serif text-[15px] leading-[1.9] text-gray-900">
        {children}
      </div>

      {onAddImage && (
        <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2">
          <button
            onClick={onAddImage}
            className="text-xs px-3 py-1 rounded border bg-white/80 hover:bg-white shadow-sm"
            title="Insérer une image sur cette page"
          >
            ➕ Image
          </button>
        </div>
      )}

      {showFooter && (
        <div className="absolute bottom-0 left-0 right-0 px-10 py-4 text-xs text-gray-500 flex items-center justify-between pointer-events-none">
          <span>MemoSphere — {bookTitle || "Livre"}</span>
          <span>{pageNumber}</span>
        </div>
      )}
    </div>
  );
}

function EditableBlock({
  html,
  onChange,
  className = "",
  enableImageDelete = false,
}: {
  html: string;
  onChange: (html: string) => void;
  className?: string;
  enableImageDelete?: boolean;
}) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (document.activeElement !== el) el.innerHTML = html || "";
    if (!enableImageDelete) return;
    // Ajoute un bouton de suppression sur chaque image inline
    try {
      const imgs = el.querySelectorAll("img");
      imgs.forEach((img) => {
        const parent = img.parentElement;
        if (!parent) return;
        parent.classList.add("relative", "group");
        if (parent.querySelector('[data-img-delete]')) return;
        const btn = document.createElement("button");
        btn.type = "button";
        btn.setAttribute("data-img-delete", "1");
        btn.setAttribute("title", "Supprimer l'image");
        btn.setAttribute("aria-label", "Supprimer l'image");
        btn.setAttribute("contenteditable", "false");
        btn.className = "absolute -top-2 -right-2 opacity-0 group-hover:opacity-100 transition-opacity text-xs px-2 py-1 rounded-full bg-white border shadow hover:bg-red-50 hover:text-red-600";
        btn.textContent = "×";
        btn.addEventListener("click", (ev) => {
          ev.preventDefault();
          ev.stopPropagation();
          // Retire le conteneur de l'image si possible, sinon seulement l'image
          if (parent && parent !== el) parent.remove();
          else img.remove();
          onChange(el.innerHTML);
        });
        parent.appendChild(btn);
      });
    } catch {}
  }, [html]);

  return (
    <div
      ref={ref}
      contentEditable
      suppressContentEditableWarning
      onInput={(e) => onChange((e.target as HTMLDivElement).innerHTML)}
      onBlur={(e) => onChange((e.target as HTMLDivElement).innerHTML)}
      className={`outline-none ${className}`}
    />
  );
}

export default function FinalBookPage() {
  
  const router = useRouter();
  const { blocks } = (useBlocks() as any) || {};
  const allBlocks: Block[] = useMemo(() => {
    const vals = blocks ? Object.values(blocks) : [];
    return (vals as any[]).map((b) => ({
      id: String(b?.id ?? ""),
      title: String(b?.title ?? b?.id ?? ""),
      summary: String(b?.summary ?? ""),
    }));
  }, [blocks]);

  const [bookTitle, setBookTitle] = useState("");
  const [subtitle, setSubtitle] = useState("");
  const [style, setStyle] = useState("narratif");
  const [order, setOrder] = useState<string[]>([]);
  const [titlesById, setTitlesById] = useState<Record<string, string>>({});
  const [prefaceHtml, setPrefaceHtml] = useState("<em>Préface (en cours de construction)</em>");
  const [conclusionHtml, setConclusionHtml] = useState("<em>Conclusion — à compléter</em>");
  const [chapters, setChapters] = useState<Chapter[]>([]);
  const [history, setHistory] = useState<string[]>([]);
  const inputFileRef = useRef<HTMLInputElement | null>(null);
  const pendingImageTargetRef = useRef<number | null>(null);
  const pendingChapterPageRef = useRef<number | null>(null);
  const [prefaceImages, setPrefaceImages] = useState<Array<string | { page: number; src: string }>>([]);
  const [conclusionImages, setConclusionImages] = useState<Array<string | { page: number; src: string }>>([]);
// Pages vierges ajoutées manuellement
const [extraPages, setExtraPages] = useState<{ afterPage: number; id: string }[]>([]);

  const pageCounterRef = useRef(0);
  const nextPageNumber = () => (pageCounterRef.current += 1);

  const debouncedSave = useMemo(
    () =>
      debounce(() => {
        const payload = { prefaceHtml, chapters, conclusionHtml, prefaceImages, conclusionImages };
        try {
          localStorage.setItem(LS_KEY_FINAL, JSON.stringify(payload));
        } catch {}
        try {
          pushHistory(payload);
        } catch {}
      }, 700),
    [prefaceHtml, chapters, conclusionHtml, prefaceImages, conclusionImages]
  );
  // Ajout d'une page vierge à la suite d'une page donnée
function addBlankPage(afterPage: number) {
  setExtraPages((prev) => {
    const newPage = { afterPage, id: `blank-${Date.now()}` };
    const next = [...prev, newPage];
    try {
      localStorage.setItem("draft:final:blankPages", JSON.stringify(next));
    } catch {}
    return next;
  });
}

  useEffect(() => {
    debouncedSave();
  }, [prefaceHtml, chapters, conclusionHtml, debouncedSave]);

  // Utilitaires images chapitres
  const normalizeChapterImages = (imgs: (string | { page: number; src: string })[] | undefined | null) =>
    (imgs || []).map((img) => (typeof img === "string" ? { page: 0, src: img } : img));

  const addChapterImageAtPage = (chIdx: number, pageIdx: number, base64: string) => {
    setChapters((prev) => {
      const next = [...prev];
      const current = next[chIdx];
      if (!current) return prev;
      const curImgs = normalizeChapterImages(current.images);
      const already = curImgs.filter((i) => i.page === pageIdx).length;
      const targetPage = already ? pageIdx + 1 : pageIdx;
      const updatedImages = [...curImgs, { page: targetPage, src: base64 }];
      next[chIdx] = { ...current, images: updatedImages };
      pushHistory({ prefaceHtml, chapters: next, conclusionHtml });
      return next;
    });
    debouncedSave();
  };

  const pushHistory = (state: any) => {
    setHistory((prev) => {
      const snap = toHistorySnapshot(state);
      const next = [...prev, JSON.stringify(snap)].slice(-5);
      try {
        localStorage.setItem(LS_KEY_HISTORY, JSON.stringify(next));
      } catch {
        // Si quota dépassé, on tente de réduire l'historique
        try {
          const reduced = next.slice(-3);
          localStorage.setItem(LS_KEY_HISTORY, JSON.stringify(reduced));
          return reduced;
        } catch {}
      }
      return next;
    });
  };

  const restoreSnapshotAt = (index: number) => {
    setHistory((prev) => {
      if (!prev.length) return prev;
      const safeIdx = Math.max(0, Math.min(index, prev.length - 1));
      let parsed: any;
      try {
        parsed = JSON.parse(prev[safeIdx]);
      } catch {
        return prev;
      }
      // parsed est une version "light" sans images inline ni arrays images
      setPrefaceHtml(parsed.prefaceHtml ?? "");
      setChapters(parsed.chapters ?? []);
      setConclusionHtml(parsed.conclusionHtml ?? "");
      const next = [...prev, prev[safeIdx]].slice(-5);
      try {
        localStorage.setItem(LS_KEY_HISTORY, JSON.stringify(next));
      } catch {}
      try {
        const payload = { prefaceHtml: parsed.prefaceHtml ?? "", chapters: parsed.chapters ?? [], conclusionHtml: parsed.conclusionHtml ?? "" };
        localStorage.setItem(LS_KEY_FINAL, JSON.stringify(payload));
      } catch {}
      return next;
    });
  };

  useEffect(() => {
    try {
      const persisted = JSON.parse(localStorage.getItem(LS_KEY_BUILDER) || "null");
      if (persisted) {
        setBookTitle(persisted.bookTitle || "");
        setSubtitle(persisted.subtitle || "");
        setStyle(persisted.style || "narratif");
        setOrder(persisted.order || []);
        setTitlesById(persisted.titlesById || {});
      }
      const saved = JSON.parse(localStorage.getItem(LS_KEY_FINAL) || "null");
      if (saved?.chapters) setChapters(saved.chapters);
      if (saved?.prefaceHtml) setPrefaceHtml(saved.prefaceHtml);
      if (saved?.conclusionHtml) setConclusionHtml(saved.conclusionHtml);
      if (Array.isArray(saved?.prefaceImages)) setPrefaceImages(saved.prefaceImages);
      if (Array.isArray(saved?.conclusionImages)) setConclusionImages(saved.conclusionImages);
      const hist = JSON.parse(localStorage.getItem(LS_KEY_HISTORY) || "[]");
      if (hist.length) setHistory(hist);
    } catch {}
        const savedBlanks = JSON.parse(localStorage.getItem("draft:final:blankPages") || "[]");
    if (Array.isArray(savedBlanks)) setExtraPages(savedBlanks);

  }, []);

  // Hydrate from builder-generated book when redirected from builder
  useEffect(() => {
    try {
      const just = localStorage.getItem("book:justGenerated");
      const raw = localStorage.getItem("book:final");
      if (just === "true" && raw) {
        const title = localStorage.getItem("book:lastTitle") || "";
        const parts = raw.split(/^#\s+/m).filter(Boolean);
        const parsedChapters: Chapter[] = parts.map((chunk, idx) => {
          const lines = chunk.split(/\r?\n/);
          const chTitle = (lines.shift() || `Chapitre ${idx + 1}`).trim();
          const chText = lines.join("\n").trim();
          return { id: `gen-${idx}`, title: chTitle, text: chText, images: [] };
        });
        if (title) setBookTitle(title);
        if (parsedChapters.length) {
          setChapters(parsedChapters);
          pushHistory({ prefaceHtml, chapters: parsedChapters, conclusionHtml });
          try {
            localStorage.setItem(
              LS_KEY_FINAL,
              JSON.stringify({ prefaceHtml, chapters: parsedChapters, conclusionHtml })
            );
          } catch {}
        }
        localStorage.removeItem("book:justGenerated");
      }
    } catch {}
  }, []);

  useEffect(() => {
    if (!allBlocks.length) return;
    if (chapters.length) return;

    const byId = new Map(allBlocks.map((b) => [b.id, b]));
    const ids = order.length ? order : allBlocks.map((b) => b.id);

    const built: Chapter[] = ids
      .map((id) => {
        const b = byId.get(id);
        if (!b) return null;
        const title = (titlesById[id] || b.title || id).trim();
        const raw = (b.summary || "").trim();
        if (!raw) return null;
        return { id, title, text: raw, images: [] };
      })
      .filter(Boolean) as Chapter[];

    setChapters(built);
    pushHistory({ prefaceHtml, chapters: built, conclusionHtml });
  }, [allBlocks, order, titlesById]);

  const handleAddImage2 = (idx: number) => {
    const input = inputFileRef.current;
    if (!input) return;
    // Reset pour permettre la même sélection plusieurs fois d'affilée
    try {
      (input as any).value = "";
    } catch {}
    input.onchange = (e: any) => {
      const file = e.target.files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (ev) => {
        const base64 = ev.target?.result as string;
        if (idx >= 0) {
          setChapters((prev) => {
            const next = [...prev];
            const current = next[idx];
            if (!current) return prev;
            const updatedImages = [...(current.images || []), base64];
            next[idx] = { ...current, images: updatedImages };
  const handleAddImage2 = (idx: number) => {
    const input = inputFileRef.current;
    if (!input) return;
    pendingImageTargetRef.current = idx;
    try { (input as any).value = ""; } catch {}
    input.click();
  };
            pushHistory({ prefaceHtml, chapters: next, conclusionHtml });
            return next;
          });
          debouncedSave();
          return;
        }
        const imgBlock = `<div class=\"mt-6 flex justify-center\"><img src=\"${base64}\" alt=\"\" class=\"max-w-[80%] rounded-lg shadow-md border border-gray-200\" /></div>`;
        if (idx === -1) {
          setPrefaceHtml((prev) => {
            const html = (prev || "") + imgBlock;
            pushHistory({ prefaceHtml: html, chapters, conclusionHtml });
            return html;
          });
          debouncedSave();
          return;
        }
        if (idx === -2) {
          setConclusionHtml((prev) => {
            const html = (prev || "") + imgBlock;
            pushHistory({ prefaceHtml, chapters, conclusionHtml: html });
            return html;
          });
          debouncedSave();
          return;
        }
      };
      reader.readAsDataURL(file);
    };
    input.click();
  };

  function updateChapter(idx: number, patch: Partial<Chapter>) {
    setChapters((prev) => {
      const next = prev.slice();
      next[idx] = { ...next[idx], ...patch };
      pushHistory({ prefaceHtml, chapters: next, conclusionHtml });
      return next;
    });
    debouncedSave();
  }

  function removeChapterImage(chIdx: number, imgIdx: number) {
    setChapters((prev) => {
      const next = [...prev];
      const current = next[chIdx];
      if (!current) return prev;
      const imgs = [...(current.images || [])];
      if (imgIdx < 0 || imgIdx >= imgs.length) return prev;
      imgs.splice(imgIdx, 1);
      next[chIdx] = { ...current, images: imgs };
      pushHistory({ prefaceHtml, chapters: next, conclusionHtml });
      return next;
    });
    debouncedSave();
  }

  function removePrefaceImage(imgIdx: number) {
    setPrefaceImages((prev) => {
      const next = [...prev];
      if (imgIdx < 0 || imgIdx >= next.length) return prev;
      next.splice(imgIdx, 1);
      pushHistory({ prefaceHtml, chapters, conclusionHtml });
      return next;
    });
    debouncedSave();
  }

  function removeConclusionImage(imgIdx: number) {
    setConclusionImages((prev) => {
      const next = [...prev];
      if (imgIdx < 0 || imgIdx >= next.length) return prev;
      next.splice(imgIdx, 1);
      pushHistory({ prefaceHtml, chapters, conclusionHtml });
      return next;
    });
    debouncedSave();
  }

  pageCounterRef.current = 0;
  const tableOfContents = chapters.map((ch, i) => `Chapitre ${i + 1} — ${ch.title}`);

  return (
    <div className="max-w-[1200px] mx-auto p-6 space-y-8">
      <input type="file" ref={inputFileRef} accept="image/*" onChange={async (e) => {
        const file = (e.target as HTMLInputElement).files?.[0];
        if (!file) return;
        const idx = pendingImageTargetRef.current;
        const pageIdx = pendingChapterPageRef.current;
        pendingImageTargetRef.current = null;
        pendingChapterPageRef.current = null;
        let base64 = '';
        try { base64 = await compressImage(file); } catch { return; }
        if (idx !== null && idx >= 0) {
          addChapterImageAtPage(idx, Math.max(0, pageIdx ?? 0), base64);
          return;
        }
        if (idx === -1) {
          setPrefaceImages((prev) => {
            const next = [...prev, { page: Math.max(0, pageIdx ?? 0), src: base64 }];
            pushHistory({ prefaceHtml, chapters, conclusionHtml });
            return next;
          });
          debouncedSave();
          return;
        }
        if (idx === -2) {
          setConclusionImages((prev) => {
            const next = [...prev, { page: Math.max(0, pageIdx ?? 0), src: base64 }];
            pushHistory({ prefaceHtml, chapters, conclusionHtml });
            return next;
          });
          debouncedSave();
          return;
        }
      }} style={{ display: "none" }} />

      <div className="sticky top-0 z-50 bg-[#fdfaf6] flex items-center justify-between py-2 border-b border-gray-200 shadow-sm">
        <PageNavButtons show={["home", "draft", "blocks"]} />
        <div className="flex items-center gap-4">
          <button
            onClick={() => {
              if (history.length > 1) {
                restoreSnapshotAt(history.length - 2);
              }
            }}
            className="hidden text-sm px-3 py-1 rounded border bg-white hover:bg-gray-50 shadow-sm"
          >
            ↩ Annuler dernière action
          </button>
          <div className="flex items-center gap-2">
            <label className="text-xs text-gray-500">Historique</label>
            <select
              className="text-sm px-2 py-1 rounded border bg-white hover:bg-gray-50 shadow-sm"
              onChange={(e) => {
                const v = Number(e.target.value);
                if (!Number.isNaN(v)) restoreSnapshotAt(v);
              }}
              value={history.length ? String(history.length - 1) : ''}
            >
              {history.map((_, i) => (
                <option key={i} value={i}>
                  Sauvegarde #{i + 1}{i === history.length - 1 ? ' (récente)' : ''}
                </option>
              ))}
              {!history.length && <option value="">Aucune</option>}
            </select>
          </div>
          <div className="text-xs text-gray-500">
            Rendu final — édition directe (autosave)
          </div>
        </div>
      </div>

      {/* Couv */}
      <BookPage showFooter={false} noShadow>
        <div className="h-full flex flex-col items-center justify-center text-center text-white">
          <div className="relative w-[520px] h-[760px] rounded-xl overflow-hidden shadow-2xl">
            <div className="absolute inset-0 bg-gradient-to-br from-[#6BA5C8] to-[#9DC8A5]" />
            <div className="absolute inset-0 flex flex-col items-center justify-center px-10">
              <EditableBlock
                html={`<div class='text-4xl font-extrabold drop-shadow-md'>${bookTitle || "Titre du livre"}</div>`}
                onChange={(html) => setBookTitle(html.replace(/<[^>]+>/g, ""))}
                className="text-white"
              />
              <div className="mt-4 opacity-90">
                <EditableBlock
                  html={`<div class='text-xl italic'>${subtitle || "Sous-titre du livre"}</div>`}
                  onChange={(html) => setSubtitle(html.replace(/<[^>]+>/g, ""))}
                  className="text-white"
                />
              </div>
              <div className="absolute top-6 right-6">
                <button className="text-xs bg-white/30 px-3 py-1 rounded hover:bg-white/50">
                  ✏️ Éditer la couverture
                </button>
              </div>
              <div className="absolute bottom-8 text-xs tracking-wide opacity-85">
                MEMOSPHERE BOOK
              </div>
            </div>
          </div>
        </div>
      </BookPage>

      {/* Sommaire */}
      <BookPage showFooter pageNumber={nextPageNumber()} bookTitle={bookTitle}>
        <h2 className="text-2xl font-serif mb-6 text-center">Sommaire</h2>
        <ul className="space-y-2 text-lg">
          {tableOfContents.map((line, i) => (
            <li key={i}>{line}</li>
          ))}
        </ul>
      </BookPage>

            {/* Préface paginée */}
      {paginateTextByHeight(String(prefaceHtml || '')).map((pageText, pageIdx) => (
        <BookPage
          key={`preface-page-${pageIdx}`}
          showFooter
          pageNumber={nextPageNumber()}
          bookTitle={bookTitle}
          onAddImage={() => { pendingImageTargetRef.current = -1; pendingChapterPageRef.current = pageIdx; const input = inputFileRef.current; if (input) { try { (input as any).value = ""; } catch {} input.click(); } }}
        >
          {pageIdx === 0 && (
            <h2 className="text-2xl font-serif mb-6 text-center">Préface</h2>
          )}
          <EditableBlock
            html={`<div class='prose prose-neutral max-w-none'>${pageText.split("\n\n").map((para) => `<p>${para}</p>`).join("")}</div>`}
            onChange={(html) => {
              const pages = paginateTextByHeight(String(prefaceHtml || ''));
              const updated = [...pages];
              updated[pageIdx] = html.replace(/<[^>]+>/g, '');
              const merged = updated.join("\n\n");
              setPrefaceHtml(merged);
            }}
            enableImageDelete
            className="h-[780px] overflow-auto"
          />
        </BookPage>        
      ))}
      {/* Bouton pour ajouter une page vierge après celle-ci */}
<div className="flex justify-center mb-8">
  <button
    onClick={() => addBlankPage(pageCounterRef.current)}
    className="text-sm px-3 py-1 rounded border bg-white hover:bg-gray-50 shadow-sm"
  >
    ➕ Ajouter une page vierge après cette page
  </button>
</div>

      {conclusionImages.map((src, i) => (
        <BookPage
          key={`concl-img-${i}`}
          showFooter
          pageNumber={nextPageNumber()}
          bookTitle={bookTitle}
        >
          <div className="mt-6 flex justify-center group relative">
            <img
              src={typeof src === "string" ? src : src?.src}
              alt=""
              className="max-w-[80%] max-h-[820px] object-contain rounded-lg shadow-md border border-gray-200"
            />
            <button
              type="button"
              onClick={() => removeConclusionImage(i)}
              title="Supprimer l'image"
              aria-label="Supprimer l'image"
              className="absolute -top-2 right-10 opacity-0 group-hover:opacity-100 transition-opacity text-xs px-2 py-1 rounded-full bg-white border shadow hover:bg-red-50 hover:text-red-600"
            >
              ×
            </button>
          </div>
        </BookPage>
        
      ))}
      
      {prefaceImages.map((src, i) => (
        <BookPage
          key={`preface-img-${i}`}
          showFooter
          pageNumber={nextPageNumber()}
          bookTitle={bookTitle}
        >
          <div className="mt-6 flex justify-center group relative">
            <img
              src={typeof src === "string" ? src : src?.src}
              alt=""
              className="max-w-[80%] max-h-[820px] object-contain rounded-lg shadow-md border border-gray-200"
            />
            <button
              type="button"
              onClick={() => removePrefaceImage(i)}
              title="Supprimer l'image"
              aria-label="Supprimer l'image"
              className="absolute -top-2 right-10 opacity-0 group-hover:opacity-100 transition-opacity text-xs px-2 py-1 rounded-full bg-white border shadow hover:bg-red-50 hover:text-red-600"
            >
              ×
            </button>
          </div>
        </BookPage>
      ))}

      {/* Chapitres: pagination multi-pages avec insertion d'image par page */}
      {chapters.map((ch, chIdx) => {
        const pages = paginateTextByHeight(ch.text);
        const imgs = normalizeChapterImages(ch.images);
        return (
          <React.Fragment key={ch.id}>
            {pages.map((pageText, pageIdx) => {
              const pageImages = imgs.filter((i) => i.page === pageIdx);
              return (
                <BookPage
                  key={`${ch.id}-page-${pageIdx}`}
                  showFooter
                  pageNumber={nextPageNumber()}
                  bookTitle={bookTitle}
                  onAddImage={() => {
                    pendingImageTargetRef.current = chIdx;
                    pendingChapterPageRef.current = pageIdx;
                    const input = inputFileRef.current; if (input) { try { (input as any).value = ""; } catch {} input.click(); }
                  }}
                >
                  <div className="mb-10">
                    {pageIdx === 0 && (
                      <>
                        <div className="text-xs tracking-[0.25em] uppercase text-gray-400">Chapitre {chIdx + 1}</div>
                        <EditableBlock
                          html={`<div class='mt-2 text-2xl font-serif'>${ch.title}</div>`}
                          onChange={(html) => updateChapter(chIdx, { title: html.replace(/<[^>]+>/g, "").trim() })}
                        />
                      </>
                    )}
                  </div>

                  <EditableBlock
                    html={`<div class='prose prose-neutral max-w-none'>${pageText.split("\n\n").map((para) => `<p>${para}</p>`).join("")}</div>`}
                    onChange={(html) => {
                      // Reconstruire le texte complet en remplaçant la page modifiée
                      const all = paginateTextByHeight(ch.text);
                      all[pageIdx] = html.replace(/<[^>]+>/g, "");
                      const merged = all.join("\n\n");
                      updateChapter(chIdx, { text: merged });
                    }}
                    className="h-[780px] overflow-auto"
                  />

                  {pageImages.map((img, i) => (
                    <div key={i} className="mt-6 flex justify-center group relative">
                      <img src={img.src} alt="" className="max-w-[80%] rounded-lg shadow-md border border-gray-200" />
                      <button
                        type="button"
                        onClick={() => {
                          // Supprime i-ème image de cette page
                          setChapters((prev) => {
                            const next = [...prev];
                            const current = next[chIdx];
                            if (!current) return prev;
                            const curImgs = normalizeChapterImages(current.images);
                            const pageIdxs = curImgs.reduce<number[]>((acc, it, idx2) => { if (it.page === pageIdx) acc.push(idx2); return acc; }, []);
                            const removeAt = pageIdxs[i];
                            if (removeAt == null) return prev;
                            curImgs.splice(removeAt, 1);
                            next[chIdx] = { ...current, images: curImgs };
                            pushHistory({ prefaceHtml, chapters: next, conclusionHtml });
                            return next;
                          });
                          debouncedSave();
                        }}
                        title="Supprimer l'image"
                        aria-label="Supprimer l'image"
                        className="absolute -top-2 -right-2 opacity-0 group-hover:opacity-100 transition-opacity text-xs px-2 py-1 rounded-full bg-white border shadow hover:bg-red-50 hover:text-red-600"
                      >
                        ×
                      </button>
                    </div>
                  ))}
                </BookPage>
                
              );
              
            })}
            {/* Bouton pour ajouter une page vierge après celle-ci */}
<div className="flex justify-center mb-8">
  <button
    onClick={() => addBlankPage(pageCounterRef.current)}
    className="text-sm px-3 py-1 rounded border bg-white hover:bg-gray-50 shadow-sm"
  >
    ➕ Ajouter une page vierge après cette page
  </button>
</div>

          </React.Fragment>
        );
      })}

            {/* Conclusion paginée */}
      {paginateTextByHeight(String(conclusionHtml || '')).map((pageText, pageIdx) => (
        <BookPage
          key={`conclusion-page-${pageIdx}`}
          showFooter
          pageNumber={nextPageNumber()}
          bookTitle={bookTitle}
          onAddImage={() => { pendingImageTargetRef.current = -2; pendingChapterPageRef.current = pageIdx; const input = inputFileRef.current; if (input) { try { (input as any).value = ""; } catch {} input.click(); } }}
        >
          {pageIdx === 0 && (
            <h2 className="text-2xl font-serif mb-6 text-center">Conclusion</h2>
          )}
          <EditableBlock
            html={`<div class='prose prose-neutral max-w-none'>${pageText.split("\n\n").map((para) => `<p>${para}</p>`).join("")}</div>`}
            onChange={(html) => {
              const pages = paginateTextByHeight(String(conclusionHtml || ''));
              const updated = [...pages];
              updated[pageIdx] = html.replace(/<[^>]+>/g, '');
              const merged = updated.join("\n\n");
              setConclusionHtml(merged);
            }}
            enableImageDelete
            className="h-[780px] overflow-auto"
          />
        </BookPage>
      ))}
    </div>
    
  );
  
}








